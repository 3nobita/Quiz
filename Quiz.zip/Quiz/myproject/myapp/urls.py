from django.urls import path
from . import views
from .views import quiz 
from django.conf import settings
from django.conf.urls.static import static
from django.contrib.auth import views as auth_views 


urlpatterns = [
    path('', views.index, name='index'),
    path('login/', views.user_login, name='login'),
    path('signup/', views.signup, name='signup'),
    path('logout/', views.user_logout, name='logout'),
    path('setting',views.setting,name='setting'),
    path('home/', views.home_page, name='home'),
    path('quiz/<str:category>/', quiz, name='quiz'),
    path('quiz_completed/<str:category>/', views.quiz_completed, name='quiz_completed'),
    path('quiz_completed/', views.quiz_completed, name='quiz_completed'),
    path('demo',views.demo,name='demo'),
    path('quiz_category',views.quiz_category,name='quiz_category'),
    path('coding',views.coding,name='coding'),
    path('home/profile',views.profile,name='profile'),
    path('greetings',views.greetings,name='greetings'),
    path('home/run/', views.runcode, name='runcode'),
    path('python_com', views.python_com, name='python_com'),
    path('js_com', views.js_com, name='js_com'),
    path('js_greet',views.js_greet,name='js_greet'),
    path('js/run/', views.jscode, name='jscode'),
    path('java_greet',views.java_greet,name='java_greet'),
    path('javacode/run/', views.javacode, name='javacode'),
    path('java_com', views.java_com, name='java_com'),
    
    # forget password 
    

  
    
] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
