var paragraphElement = document.getElementById('myParagraph');
var paragraphText = paragraphElement.textContent;

function readText() {
  var speechUtterance = new SpeechSynthesisUtterance(paragraphText);
  speechSynthesis.speak(speechUtterance);
  var audio = new Audio('path/to/your/sound.mp3');

  // Play the sound
  audio.play();
}

console.log(paragraphText);

// toggle 

function toggleSidebar() {
  var sidebar = document.getElementById('sidebar');
  sidebar.classList.toggle('collapsed');
  var mainContent = document.querySelector('.main-content');
  if (sidebar.classList.contains('collapsed')) {
      mainContent.style.marginLeft = '0';
  } else {
      mainContent.style.marginLeft = '200px';
  }
}

function changeTheme() {
  var selectedTheme = document.querySelector('input[name="theme"]:checked').value;
  document.querySelectorAll('.themeImage').forEach(function (img) {
      img.src = selectedTheme;
  });
  toggleSidebar();
}

function selectTheme(theme) {
  document.querySelectorAll('.themeImage').forEach(function (img) {
      img.src = theme;
  });
  toggleSidebar();
}


// Read Text
// function readText() {
//   var paragraphElement = document.getElementById('myParagraph');
//   var paragraphText = paragraphElement.textContent;
  
//   var speechUtterance = new SpeechSynthesisUtterance(paragraphText);
//   speechSynthesis.speak(speechUtterance);
  
//   var audio = new Audio('path/to/your/sound.mp3');
//   audio.play();
// }

// // Toggle Sidebar
// function toggleSidebar() {
//   var sidebar = document.getElementById('sidebar');
//   sidebar.classList.toggle('collapsed');
  
//   var mainContent = document.querySelector('.main-content');
//   mainContent.style.marginLeft = sidebar.classList.contains('collapsed') ? '0' : '200px';
// }

// // Change Theme
// function changeTheme() {
//   var selectedTheme = document.querySelector('input[name="theme"]:checked').value;
  
//   document.querySelectorAll('.themeImage').forEach(function (img) {
//       img.src = selectedTheme;
//   });
  
//   toggleSidebar();
// }

// // Select Theme
// function selectTheme(theme) {
//   document.querySelectorAll('.themeImage').forEach(function (img) {
//       img.src = theme;
//   });
  
//   toggleSidebar();
// }
