$(document).ready(function(){
    // Questions data
    var questions = [
      {"id": 1, "text": "Write a Python function to calculate the factorial of a number."},
      {"id": 2, "text": "Write a Python program to check if a given number is prime or not."},
      // Add more questions as needed
    ];
  
    // Current question index
    var currentQuestionIndex = 0;
  
    // Function to display the current question
    function displayQuestion() {
      $('#questionText').text(questions[currentQuestionIndex].text);
    }
  
    // Initial question display
    displayQuestion();
  
    // Next Question button click event
    $('#next-question').click(function() {
      currentQuestionIndex++;
      if (currentQuestionIndex < questions.length) {
        displayQuestion();
      } else {
        alert('You have completed all questions!');
        // You can perform any action when all questions are completed
      }
    });
  });
  