var paragraphElement = document.getElementById('myParagraph');
var paragraphText = paragraphElement.textContent;

function readText() {
  // Use the Web Speech API to read the text
  var speechUtterance = new SpeechSynthesisUtterance(paragraphText);
  speechSynthesis.speak(speechUtterance);

  // Create an Audio element with the sound file path
  var audio = new Audio('path/to/your/sound.mp3');

  // Play the sound
  audio.play();
}

console.log(paragraphText);