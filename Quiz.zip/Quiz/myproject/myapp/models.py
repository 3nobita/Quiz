from django.db import models
from django.contrib.auth.models import User

class Question(models.Model):  # inherits

    question_text = models.CharField(max_length=200)
    option_a = models.CharField(max_length=100)
    option_b = models.CharField(max_length=100)
    option_c = models.CharField(max_length=100)
    option_d = models.CharField(max_length=100)
    correct_answer = models.CharField(
        max_length=1, choices=[('A', 'A'), ('B', 'B'), ('C', 'C'), ('D', 'D')])
    CATEGORY_CHOICES = [
        ('html', 'html'),
        ('css', 'css'),
        ('JavaScript', 'JavaScript'),
        ('python', 'python'),
        ('react', 'react'),
        ('node-js', 'node-js'),
        ('mysql', 'mysql'),
        ('django', 'django'),

    ]

    def __str__(self):
        return self.question_text

    category = models.CharField(max_length=10, choices=CATEGORY_CHOICES)

# profile 

class Profile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    image = models.ImageField(default='default.jpg', upload_to='profile_pics')

    def __str__(self):
        return f'{self.user.username} Profile'