from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
from .models import Question
from .models import Profile


class SignupForm(UserCreationForm):
    class Meta:
        model = User
        fields = ['username', 'password1', 'password2']

class LoginForm(forms.Form):
    username = forms.CharField()
    password = forms.CharField(widget=forms.PasswordInput)




class QuizForm(forms.ModelForm):
    user_answer = forms.ChoiceField(
        choices=[('A', 'A'), ('B', 'B'), ('C', 'C'), ('D', 'D')],
        widget=forms.RadioSelect,
        required=True
    )
    class Meta: # handle and process the form
        model = Question
        fields = []


# img work

class ProfileForm(forms.ModelForm):
    class Meta:
        model = Profile
        fields = ['image']
        
    def __init__(self, *args, **kwargs):
        super(ProfileForm, self).__init__(*args, **kwargs)
        self.fields['image'].widget.attrs.update({'class': 'form-control-file'}) 
        

# change password and user name 

