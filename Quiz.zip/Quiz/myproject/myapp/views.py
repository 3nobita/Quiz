from django.contrib.auth.forms import PasswordChangeForm
from django.shortcuts import render, redirect
# from django.contrib.auth import update_session_auth_hash
from .models import Profile
from django.core.exceptions import ObjectDoesNotExist
from .forms import ProfileForm
from django.contrib.auth.decorators import login_required
import statistics
import subprocess
from datetime import datetime
import os
from django.urls import reverse
from django.http import HttpResponseRedirect
from django.shortcuts import render
import sys
from django.shortcuts import render, redirect, HttpResponse
from django.contrib.auth import authenticate, login, logout, update_session_auth_hash
from django.contrib import messages
from django.contrib.auth import authenticate, login as auth_login, logout
# from myproject.myproject.settings import STATIC_URL
from .forms import SignupForm, LoginForm, User
from .models import Question
from .forms import QuizForm
from .forms import UserCreationForm, LoginForm
from .models import Question
from .forms import QuizForm


# Home page
def index(request):
    return render(request, 'index.html')

# signup page


# def signup(request):
#     if request.method == 'POST':
#         form = UserCreationForm(request.POST)
#         if form.is_valid():
#             form.save()
#             return redirect('login')
#     else:
#         form = UserCreationForm()
#     return render(request, 'signup.html', {'form': form})

# # login page


# def login(request):
#     if request.method == 'POST':
#         form = LoginForm(request.POST)
#         if form.is_valid():
#             username = form.cleaned_data['username']
#             password = form.cleaned_data['password']
#             user = authenticate(request, username=username, password=password)
#             if user:
#                 login(request, user)
#                 return redirect('home')
#     else:
#         form = LoginForm()
#     return render(request, 'login.html', {'form': form})

# logout page

# def SignupPage(request):
#     if request.method == 'POST':
#         uname = request.POST.get('username')
#         email = request.POST.get('email')
#         pass1 = request.POST.get('password1')
#         pass2 = request.POST.get('password2')

#         if pass1 != pass2:
#             return HttpResponse("Your password and confrom password are not Same!!")
#         else:

#             my_user = User.objects.create_user(uname, email, pass1)
#             my_user.save()
#             return redirect('login')
#     return render(request, 'signup.html')


# def LoginPage(request):
#     if request.method == 'POST':
#         username = request.POST.get('username')
#         pass1 = request.POST.get('pass')
#         user = authenticate(request, username=username, password=pass1)
#         if user is not None:
#             login(request, user)
#             return redirect('home')
#         else:
#             return HttpResponse("Username or Password is incorrect!!!")

#     return render(request, 'login.html')
def signup(request):
    if request.method == 'POST':
        uname = request.POST.get('username')
        email = request.POST.get('email')
        pass1 = request.POST.get('password1')
        pass2 = request.POST.get('password2')

        if pass1 != pass2:
            return HttpResponse("Your password and confrom password are not Same!!")
        else:

            my_user = User.objects.create_user(uname, email, pass1)
            my_user.save()
            return redirect('login')
    return render(request, 'signup.html')


def user_login(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(request, username=username, password=password)
        if user is not None:
            auth_login(request, user)
            return redirect('home')
        else:
            return HttpResponse("Username or Password is incorrect!!!")

    return render(request, 'login.html')


def user_logout(request):
    logout(request)
    return redirect('login')


def home_page(req):
    return render(req, 'home.html')

# .. quiz start


def quiz(request, category):
    questions = Question.objects.filter(category=category)  # retrieve a subset
    total_questions = len(questions)
    current_question_index = request.session.get('current_question_index', 0)

    # end of the quiz.
    if current_question_index >= total_questions:
        # HTTP.Attribute/current_user.Method
        score = request.session.get('score', 0)
        request.session['current_question_index'] = 0  # Quiz flow
        request.session['score'] = 0

        return render(request, 'quiz_completed.html', {'score': score, 'total_questions': total_questions})

    # displaying the current question
    current_question = questions[current_question_index]

    if request.method == 'POST':  # handle submission
        form = QuizForm(request.POST)  # data sent to the server
        if form.is_valid():
            user_answer = form.cleaned_data['user_answer']
            if user_answer == current_question.correct_answer:
                request.session['score'] = request.session.get('score', 0) + 1

            current_question_index += 1
            # handles updating
            request.session['current_question_index'] = current_question_index

            return redirect('quiz', category=category)   # 'category' parameter
    else:
        form = QuizForm()

    form.fields['user_answer'].choices = [
        (option, getattr(current_question, f'option_{option.lower()}')) for option in ['A', 'B', 'C', 'D']
    ]  # Access

    return render(request, 'quiz.html', {'form': form, 'current_question': current_question})


def quiz_completed(request, category=None):
    questions = Question.objects.filter(category=category)
    total_questions = len(questions)
    score = request.session.get('score', 0)
    percentage_score = (score / total_questions) * \
        100 if total_questions > 0 else 0

    # Reset session variables to start the quiz again
    request.session['current_question_index'] = 0
    request.session['score'] = 0

    return render(request, 'quiz_completed.html', {'score': score, 'total_questions': total_questions, 'percentage_score': percentage_score})


def demo(req):
    return render(req, 'demo.html')


def quiz_category(req):
    return render(req, 'quiz_category.html')


def coding(req):
    return render(req, 'coding.html')


@login_required
def profile(request):
    try:
        profile_instance = request.user.profile
    except ObjectDoesNotExist:
        # If the profile doesn't exist, create a new one
        profile_instance = Profile(user=request.user)
        profile_instance.save()

    if request.method == 'POST':
        form = ProfileForm(request.POST, request.FILES,
                           instance=profile_instance)
        if form.is_valid():
            form.save()
            return redirect('profile')
    else:
        form = ProfileForm(instance=profile_instance)

    context = {
        'form': form
    }
    return render(request, 'profile.html', context)


# update pass & username


def setting(req):
    fm = PasswordChangeForm(user=req)
    if req.method == 'POST':
        fm = PasswordChangeForm(user=req.user, data=req.POST)
    if fm.is_valid():
        user = fm.save()
        update_session_auth_hash(req, user)
        messages.success(req, 'successfully updated passwrod')
        return redirect('profile')
    else:
        fm = PasswordChangeForm(user=req.user)
    return render(req, 'setting.html', {'fm': fm})


def python_com(req):
    return render(req, 'python_com.html')


def js_com(req):
    return render(req, 'js_com.html')


# python_com
def greetings(request):
    res = render(request, 'python_com.html')
    return res


def runcode(request):
    if request.method == 'POST':
        code_part = request.POST['code_area']
        # Retrieve input from the HTML form
        input_part = request.POST['input_area']

        output_folder = 'output_data'  # Define the folder where you want to save the output
        code_folder = 'code_data'  # Define the folder where you want to save the output

        # Create the output folder if it doesn't exist
        os.makedirs(output_folder, exist_ok=True)
        os.makedirs(code_folder, exist_ok=True)

        input_list = input_part.splitlines()  # Split input by lines

        def custom_input():
            nonlocal input_list
            if input_list:
                return input_list.pop(0)
            else:
                # Raise an exception if no more input
                raise EOFError("No more input available")

        try:
            orig_stdout = sys.stdout
            # Path to save the output file

            code_file_path = os.path.join(code_folder, 'code.txt')
            with open(code_file_path, 'w') as f:
                f.write(code_part)

            output_file_path = os.path.join(output_folder, 'output.txt')
            with open(output_file_path, 'w') as f:
                sys.stdout = f

                # Pass custom_input function as input
                exec(code_part, {'input': custom_input})
            sys.stdout = orig_stdout
            with open(output_file_path, 'r') as f:
                output = f.read()  # Read the output from the file
            print("OUTPUT :: ", output)
            print("USER KA CODE :: ", code_part)
            print("USER KA INPUT :: ", input_part)

        except Exception as e:
            sys.stdout = orig_stdout
            output = str(e)

        return render(request, 'python_com.html', {"code": code_part, "input": input_part, "output": output})
    else:
        # Redirect to the same view URL but with a trailing slash
        return HttpResponseRedirect(reverse('runcode') + '/')


# js compiler
def js_greet(request):
    return render(request, 'js_com.html')

def jscode(request):
    if request.method == 'POST':
        code_part = request.POST['code_area']
        input_part = request.POST['input_area']
        js_output = 'user_js_ans2'

        os.makedirs(js_output, exist_ok=True)

        try:
            with open('script.js', 'w') as f:
                f.write(code_part)

            process = subprocess.Popen(
                ['node', 'script.js'], stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            output, error = process.communicate(input=input_part.encode())

            output = output.decode()
            error = error.decode()
            print('OUTPUT :: ', output)
            # print('CODE :: ', code_part)

            if error:
                output = error  # If there's an error, display it as output

        except Exception as e:
            output = str(e)

        jsoutput_file_path = os.path.join(js_output, 'test0.txt')
        with open(jsoutput_file_path, 'w') as f:
            f.write(output)

        return render(request, 'js_com.html', {"code": code_part, "input": input_part, "output": output})
    else:
        return HttpResponseRedirect(reverse('jscode') + '/')

def compare_files(file1_path, file2_path):
    try:
        with open(file1_path, 'r') as file1, open(file2_path, 'r') as file2:
            content1 = file1.read()
            content2 = file2.read()

            if content1 == content2:
                return "They are the same"
            else:
                return "They are different"
    except FileNotFoundError:
        return "One or both files not found"

my_js_ans = "./my_js_ans1"
user_js_ans = "./user_js_ans2"
file1_path = os.path.join(my_js_ans, "test0.txt")
file2_path = os.path.join(user_js_ans, "test0.txt")

result = compare_files(file1_path, file2_path)
print(result)


def java_com(req):
    return render(req, 'java_com.html')

def java_greet(request):
    return render(request, 'java_com.html')


def javacode(request):
    if request.method == 'POST':
        code_part = request.POST['code_area']
        input_part = request.POST['input_area']
        java_output = 'user_java_ans'

        os.makedirs(java_output, exist_ok=True)

        try:
            with open('Main.java', 'w') as f:
                f.write(code_part)

            # Compile the Java code
            compile_process = subprocess.Popen(
                ['javac', 'Main.java'], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            compile_output, compile_error = compile_process.communicate()

            if compile_error:
                output = compile_error.decode()
            else:
                # Execute the compiled Java code
                execute_process = subprocess.Popen(
                    ['java', 'Main'], stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
                output, error = execute_process.communicate(
                    input=input_part.encode())

                output = output.decode()
                error = error.decode()

                if error:
                    output = error  # If there's an error during execution, display it as output

        except Exception as e:
            output = str(e)

        java_output_file_path = os.path.join(java_output, 'output.txt')
        with open(java_output_file_path, 'w') as f:
            f.write(output)

        return render(request, 'java_com.html', {"code": code_part, "input": input_part, "output": output})
    else:
        return HttpResponseRedirect(reverse('javacode') + '/')


# def js_greet(request):
#     return render(request, 'js_com.html')


# def jscode(request):
#     def compare_files(file1_path, file2_path):
#         try:
#             with open(file1_path, 'r') as file1, open(file2_path, 'r') as file2:
#                 return "They are the same" if file1.read() == file2.read() else "They are different"
#         except FileNotFoundError:
#             return "One or both files not found"

#     if request.method == 'POST':
#         code_part = request.POST['code_area']
#         input_part = request.POST['input_area']
#         output_directory = 'user_js_ans2'
#         os.makedirs(output_directory, exist_ok=True)

#         try:
#             with open('script.js', 'w') as f:
#                 f.write(code_part)

#             process = subprocess.run(
#                 ['node', 'script.js'],
#                 input=input_part.encode(),
#                 stdout=subprocess.PIPE,
#                 stderr=subprocess.PIPE,
#                 text=True
#             )
#             output = process.stdout or process.stderr

#             with open(os.path.join(output_directory, 'test0.txt'), 'w') as f:
#                 f.write(output)

#             # Compare files
#             my_js_ans = "./my_js_ans1"
#             result = compare_files(os.path.join(
#                 my_js_ans, "test0.txt"), os.path.join(output_directory, "test0.txt"))

#         except Exception as e:
#             output = str(e)
#             result = "Error occurred"

#         return render(request, 'js_com.html', {"code": code_part, "input": input_part, "output": output, "result": result})
#     else:
#         return HttpResponseRedirect(reverse('jscode') + '/')
