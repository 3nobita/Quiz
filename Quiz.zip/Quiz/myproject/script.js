const age = parseInt(prompt());
console.log(age > 10 ? 'adult' : 'minor');
